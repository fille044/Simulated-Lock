

int getInput(int Input);
int checkInput(int Input, int Answer);
