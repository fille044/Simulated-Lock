int getLock(void);
void setLock(int State);
